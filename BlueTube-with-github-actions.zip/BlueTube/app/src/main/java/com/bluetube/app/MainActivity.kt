package com.bluetube.app

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.KeyEvent
import android.view.View
import android.webkit.*
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnPip: ImageButton
    private lateinit var btnHome: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var tvTitle: TextView

    private val YOUTUBE_URL = "https://m.youtube.com"

    // JavaScript to disable YouTube's background-pause behavior
    private val BG_PLAY_SCRIPT = """
        (function patchVisibility() {
            try {
                Object.defineProperty(document, 'hidden', {
                    get: function() { return false; },
                    configurable: true
                });
                Object.defineProperty(document, 'visibilityState', {
                    get: function() { return 'visible'; },
                    configurable: true
                });
            } catch(e) {}

            // Block all visibility-change, blur, pagehide events
            ['visibilitychange','blur','pagehide','freeze'].forEach(function(evt) {
                document.addEventListener(evt, function(e) {
                    e.stopImmediatePropagation();
                    e.preventDefault();
                }, true);
                window.addEventListener(evt, function(e) {
                    e.stopImmediatePropagation();
                    e.preventDefault();
                }, true);
            });
        })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge + status bar color
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = ContextCompat.getColor(this, R.color.nav_bar)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false

        setContentView(R.layout.activity_main)

        progressBar  = findViewById(R.id.progressBar)
        webView      = findViewById(R.id.webView)
        btnBack      = findViewById(R.id.btnBack)
        btnForward   = findViewById(R.id.btnForward)
        btnPip       = findViewById(R.id.btnPip)
        btnHome      = findViewById(R.id.btnHome)
        btnRefresh   = findViewById(R.id.btnRefresh)
        tvTitle      = findViewById(R.id.tvTitle)

        // Start background-playback foreground service
        val svc = Intent(this, BackgroundPlayService::class.java)
        ContextCompat.startForegroundService(this, svc)

        setupWebView()
        setupButtons()

        if (savedInstanceState == null) {
            webView.loadUrl(YOUTUBE_URL)
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled            = true
            domStorageEnabled            = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode         = true
            useWideViewPort              = true
            setSupportZoom(false)
            builtInZoomControls          = false
            displayZoomControls          = false
            // Mobile UA so YouTube serves its mobile UI
            userAgentString = "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
                    "AppleWebKit/537.36 (KHTML, like Gecko) " +
                    "Chrome/124.0.0.0 Mobile Safari/537.36"
            cacheMode     = WebSettings.LOAD_DEFAULT
            databaseEnabled = true
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                progressBar.visibility = View.VISIBLE
                updateNavButtons()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progressBar.visibility = View.GONE
                view?.evaluateJavascript(BG_PLAY_SCRIPT, null)
                updateNavButtons()
                tvTitle.text = view?.title ?: "BlueTube"
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                return if (url.contains("youtube.com") ||
                           url.contains("youtu.be") ||
                           url.contains("googlevideo.com") ||
                           url.contains("google.com/accounts") ||
                           url.contains("accounts.google.com")) {
                    view?.loadUrl(url)
                    true
                } else {
                    // Open external links in browser
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
                        startActivity(intent)
                    } catch (e: Exception) { }
                    true
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress == 100) progressBar.visibility = View.GONE
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                // Allow media permissions needed for playback
                request?.grant(request.resources)
            }
        }
    }

    private fun setupButtons() {
        btnHome.setOnClickListener {
            webView.loadUrl(YOUTUBE_URL)
        }

        btnRefresh.setOnClickListener {
            webView.reload()
        }

        btnBack.setOnClickListener {
            if (webView.canGoBack()) webView.goBack()
        }

        btnForward.setOnClickListener {
            if (webView.canGoForward()) webView.goForward()
        }

        btnPip.setOnClickListener {
            enterPipMode()
        }
    }

    private fun updateNavButtons() {
        btnBack.alpha    = if (webView.canGoBack())    1.0f else 0.35f
        btnForward.alpha = if (webView.canGoForward()) 1.0f else 0.35f
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (e: Exception) {
                Toast.makeText(this, "PiP not available on this device", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "PiP requires Android 8+", Toast.LENGTH_SHORT).show()
        }
    }

    // ── KEY: do NOT call webView.onPause() so audio continues in background ──
    override fun onPause() {
        super.onPause()
        // webView.onPause()  <-- intentionally omitted
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        webView.evaluateJavascript(BG_PLAY_SCRIPT, null)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Auto-enter PiP when user presses Home while watching
        enterPipMode()
    }

    override fun onPictureInPictureModeChanged(isInPiP: Boolean) {
        super.onPictureInPictureModeChanged(isInPiP)
        val uiVisibility = if (isInPiP) View.GONE else View.VISIBLE
        findViewById<View>(R.id.topBar).visibility    = uiVisibility
        findViewById<View>(R.id.bottomBar).visibility = uiVisibility
        progressBar.visibility = View.GONE
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        super.onDestroy()
        // Stop service only if we're really finishing
        if (isFinishing) {
            stopService(Intent(this, BackgroundPlayService::class.java))
        }
    }
}
