# BlueTube – personal build, no obfuscation needed
-dontwarn android.webkit.**
